<?php
 $pdo = new PDO('mysql:host=localhost;dbname=wf3_php_intermediaire_salimou', 'root', '', array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
?>
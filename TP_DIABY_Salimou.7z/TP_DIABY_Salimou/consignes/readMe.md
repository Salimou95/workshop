# TP#5 Miaou en floats
> Pour ce TP n'utilisez que la méthode flex pour positionner vos éléments.

## Colors
blanc: #ffffff
indigo: #29347B

## Font
Shadows Into Light

## Texts
- Les missions du chat
- Chat qui chasse
- Chat dort
- Chat lèche
- Chat chante
- Chat caché
- Chat a F-A-I-M
- Chat grignote
- Trop mangé
- Chat ninja
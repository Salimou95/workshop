<html>
    <table style="border: 1px solid black;">
        <thead style="background-color: grey;">
            <tr>
                <td border-collapse: collapse;>Numéro</td>
                <td>Alphabet</td>
                <td>Type</td>
                <td>Code ASCII</td>
            </tr>
        </thead>
        <tbody>
            <?php
            $alphabet = array(
                "1" => array(
                    "letrre" => "A",
                    "type" => "65",
                    "code" => "Voyelle" 
                ),
                "2" => array(
                    "letrre" => "B",
                    "type" => "66",
                    "code" => "Consonne" 
                ),
                "3" => array(
                    "letrre" => "C",
                    "type" => "67",
                    "code" => "Consonne" 
                ),
                "4" => array(
                    "letrre" => "D",
                    "type" => "68",
                    "code" => "Consonne" 
                ),
                "5" => array(
                    "letrre" => "E",
                    "type" => "69",
                    "code" => "Voyelle" 
                ),
                "6" => array(
                    "letrre" => "F",
                    "type" => "70",
                    "code" => "Consonne" 
                ),
                "7" => array(
                    "letrre" => "G",
                    "type" => "71",
                    "code" => "Consonne" 
                ),
                "8" => array(
                    "letrre" => "H",
                    "type" => "72",
                    "code" => "Consonne" 
                ),
                "9" => array(
                    "letrre" => "I",
                    "type" => "73",
                    "code" => "Voyelle" 
                ),

            )
            ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
    
    </table>
</html>
<html>
<table>
    <thead>
        <tr>
            <th>Prénoms</th>
            <th>Noms</th>
            <th>Groupe</th>
            <th>Date de naissance</th>
            <th>Adresse</th>
            <th>Code postal</th>
            <th>Gouvernorat</th>
            <th>pays</th>
        </tr>
    </thead>

    <?php
    $info = array(

        "Thamer" => array(
            "Noms" => "NAJJAR",
            "Groupe" => "TMMS1 02",
            "Date" => "12/12/1993",
            "Lieu" => "Tazarka",
            "Adresse" => "Rue ettaoufik",
            "Code" => 8000,
            "Gouvernorat" => "Nabeul",
            "Pays" => "Tunisie"
        ),
    "Mohamed" => array(
            "Noms" => "NUIRI",
            "Groupe" => "TMMS1 02",
            "Date" => "22/02/1993",
            "Lieu" => "MAAMOURA",
            "Adresse" => "Rue ettahrir",
            "Code" => 8020,
            "Gouvernorat" => "Bni Khiar",
            "Pays" => "Tunisie"
    ),
    "Mounira" => array(
                "Noms" => "HANI",
                "Groupe" => "TMMS1 02",
                "Date" => "12/12/1993",
                "Lieu" => "Tazarka",
                "Adresse" => "Rue ettaoufik",
                "Code" => 8000,
                "Gouvernorat" => "Nabeul",
                "Pays" => "Tunisie"
    ),
        "Mounira" => array(
                    "Noms" => "HANI",
                    "Groupe" => "TMMS1 02",
                    "Date" => "12/12/1993",
                    "Lieu" => "Tazarka",
                    "Adresse" => "Rue ettaoufik",
                    "Code" => 8000,
                    "Gouvernorat" => "Nabeul",
                    "Pays" => "Tunisie"
            )
    )   
    
    
    ?>
</table>

</html>


<footer>
            <div class="row text-center">
                <div class="col">
                    <p>Copyright &copy; Super Groupe Vitry- 2021</p>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row text-center -->
        </footer>
    </div>
    <!-- /.container -->
    </body>
    </html>
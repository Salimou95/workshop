<?php
include("connexion.php");
session_destroy();

?>
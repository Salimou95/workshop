<?php

include("fonction.php");
$nb = [2,5,55,20,10];
$operation = "+";
sommeTableau($nb, $operation);

?>
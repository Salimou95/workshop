<?php
var_dump($_GET);
echo $_GET["nom"];
echo $_GET["age"];
echo $_GET["sel"][1];
var_dump($_GET["sel"][0]);
var_dump($_GET["sele"][0]);
die();
?>
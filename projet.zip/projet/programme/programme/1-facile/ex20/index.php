<?php ob_start(); //NE PAS MODIFIER 
$titre = "Exo 20 : Formulaire et tableaux"; //Mettre le nom du titre de la page que vous voulez
?>

<!-- mettre ici le code -->
<!-- Exo 20 : Formulaire et tableaux
Note 1 :
Note 2 :
Note 3 :
valider -->

<?php
/************************
 * NE PAS MODIFIER
 * PERMET d INCLURE LE MENU ET LE TEMPLATE
 ************************/
    $content = ob_get_clean();
    require "../../global/common/template.php";
?>
